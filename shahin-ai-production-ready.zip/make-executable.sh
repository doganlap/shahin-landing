chmod +x deploy.sh 
